package testStore;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.Assert;
import org.junit.jupiter.api.Test;

import stores.DefaultStore;

class DefaultStoreTest {

	@Test
	void testOpenStore() {
		DefaultStore testStore = new DefaultStore();
		testStore.openStore();
		Assert.assertTrue(testStore.isStoreOpen() == false);
		//this should be false due to no inventory yet
		
	}

	@Test
	void testCloseStore() {
		DefaultStore testStore = new DefaultStore();
		testStore.closeStore();
		Assert.assertTrue(testStore.isStoreClosed() == true);	
	}

	@Test
	void testCalculateCartBalance() {
		DefaultStore testStore = new DefaultStore();
		testStore.calculateCartBalance();
		Assert.assertTrue(testStore.getCartBalance() == 0);
	}

	

}
