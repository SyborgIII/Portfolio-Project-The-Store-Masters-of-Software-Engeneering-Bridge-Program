package testForItems;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import items.SalableArmor;
import junit.framework.Assert;

class SalableArmorTest {

	@Test
	void testAddStock() {
		SalableArmor testArmor = new SalableArmor();
		testArmor.addStock(10);
		Assert.assertEquals(10, testArmor.getStock());
	}

	@Test
	void testDeductStock() {
		SalableArmor testArmor = new SalableArmor();
		testArmor.deductStock(10);
		Assert.assertEquals(-10, testArmor.getStock());	
	}

}
