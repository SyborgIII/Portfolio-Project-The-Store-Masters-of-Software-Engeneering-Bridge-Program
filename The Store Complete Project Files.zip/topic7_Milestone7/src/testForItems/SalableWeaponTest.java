package testForItems;

import org.junit.jupiter.api.Test;

import items.SalableWeapon;
import junit.framework.Assert;

@SuppressWarnings("deprecation")
class SalableWeaponTest {

	@Test
	public void testAddStock() {
		SalableWeapon testWeapon = new SalableWeapon();
		testWeapon.addStock(10);
		Assert.assertEquals(10,testWeapon.getStock());
	}

	
}
