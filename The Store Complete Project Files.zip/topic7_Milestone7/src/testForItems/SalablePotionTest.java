package testForItems;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import items.SalableArmor;
import items.SalablePotion;
import junit.framework.Assert;

class SalablePotionTest {

	@Test
	void testAddStock() {
		SalablePotion testPotion = new SalablePotion();
		testPotion.addStock(10);
		Assert.assertEquals(10, testPotion.getStock());
	}

	@Test
	void testDeductStock() {
		SalablePotion testPotion = new SalablePotion();
		testPotion.deductStock(10);
		Assert.assertEquals(-10, testPotion.getStock());	
	}
	

}
