
package drivers;

import stores.DefaultStore;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

import com.fasterxml.jackson.databind.DatabindException;

import items.SalableArmor;
import items.SalablePotion;
import items.SalableWeapon;

/**
 * 
 * @author simon codrington III
 *
 */
public class AdminClient implements Runnable {
	@Override
	public void run() {
		
		DefaultStore gameStore = new DefaultStore("Sia and Mel's Lightsabers and Stuff", true, false, 0);
		Scanner userInput = new Scanner(System.in);
		boolean resetLoop = true;
		char userYorN;
		String adminCommand;
		do {
			try {
				System.out.println("Welcome Admin. Enter a Command:");
				System.out.println("(Enter \"U\" to upload inventory or \"R\" to return inventory)");

				adminCommand = userInput.nextLine();
				switch (adminCommand.toUpperCase().charAt(0)) {
				case 'U':
					File weapon1File = new File("weapon1Json.json");
					SalableWeapon weapon1 = new SalableWeapon();
					File weapon2File = new File("weapon2Json.json");
					SalableWeapon weapon2 = new SalableWeapon();
					File armor1File = new File("armor1Json.json");
					SalableArmor armor1 = new SalableArmor();
					File armor2File = new File("armor2Json.json");
					SalableArmor armor2 = new SalableArmor();
					File potion1File = new File("potion1Json.json");
					SalablePotion potion1 = new SalablePotion();

					try {
						gameStore.addArmorToArmorInventoryListJson(armor1File, armor1);
					} catch (DatabindException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					try {
						gameStore.addArmorToArmorInventoryListJson(armor2File, armor2);
					} catch (DatabindException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					try {
						gameStore.addWeaponToWeaponInventoryListJson(weapon1File, weapon1);
					} catch (DatabindException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					try {
						gameStore.addWeaponToWeaponInventoryListJson(weapon2File, weapon2);
					} catch (DatabindException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					try {
						gameStore.addPotionToPotionInventoryListJson(potion1File, potion1);
					} catch (DatabindException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					System.out.println(
							"All items have been loaded into the store inventory. Would you like to return to the main menue? ");
					System.out.println("Please enter Y or N");
					userYorN = userInput.nextLine().toUpperCase().charAt(0);
					if (userYorN == 'N') {
						resetLoop = false;
						System.out.println("Logging out.......");
					} else {
						resetLoop = true;
					}
				case 'R':
					System.out.println("The following ietms are in inventory: ");
					System.out.println("(Inventory us empty is no return)");
					gameStore.stateWeaponList();
					gameStore.stateArmorList();
					gameStore.statePotionList();
					System.out.println("Would you like to return to main menue? Please enter Y or N");
					userYorN = userInput.nextLine().toUpperCase().charAt(0);
					if (userYorN == 'N') {
						System.out.println("Logging out.......");
						resetLoop = false;
					} else {
						resetLoop = true;

					}
				}
				
				
			}catch(Exception e) {
				System.out.println("Invalid response");
			}
		} while (resetLoop);
		userInput.close();

	}

	public static void main(String[] args) {
		
		Runnable runnable = new AdminClient();
		Thread adminThread = new Thread(runnable);
		adminThread.start();
		
	}
}
