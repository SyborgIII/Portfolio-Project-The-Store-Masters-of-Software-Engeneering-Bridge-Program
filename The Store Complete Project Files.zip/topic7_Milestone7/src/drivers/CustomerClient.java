
package drivers;

import stores.DefaultStore;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;


import items.SalableArmor;
import items.SalablePotion;
import items.SalableWeapon;

/**
 * 
 * @author simon codrington III
 *
 */
public class CustomerClient {

	public static void main(String[] args) throws IOException {
		/**
		 * non default constructor that sets the name store open status to true, closed
		 * to false, and shopping cart to 0
		 */
		DefaultStore gameStore = new DefaultStore("Sia and Mel's Lightsabers and Stuff", true, false, 0);
		Scanner userInput = new Scanner(System.in);
		boolean resetLoop = true;
		int userItemNumSelection;
		int userItemQtySelection;
		char userYorN;
		String userItemTypeRequest;

		/**
		 * adds items to inventory list for the store
		 */
		File weapon1File = new File("weapon1Json.json");
		SalableWeapon weapon1 = new SalableWeapon();
		File weapon2File = new File("weapon2Json.json");
		SalableWeapon weapon2 = new SalableWeapon();
		File armor1File = new File("armor1Json.json");
		SalableArmor armor1 = new SalableArmor();
		File armor2File = new File("armor2Json.json");
		SalableArmor armor2 = new SalableArmor();
		File potion1File = new File("potion1Json.json");
		SalablePotion potion1 = new SalablePotion();

		gameStore.addArmorToArmorInventoryListJson(armor1File, armor1);
		gameStore.addArmorToArmorInventoryListJson(armor2File, armor2);
		gameStore.addWeaponToWeaponInventoryListJson(weapon1File, weapon1);
		gameStore.addWeaponToWeaponInventoryListJson(weapon2File, weapon2);
		gameStore.addPotionToPotionInventoryListJson(potion1File, potion1);

		/**
		 * driver start
		 */

		System.out.println("Welcome to " + gameStore.getName());
		do {
			try {
				System.out.println(
						"Would you like  weapons, armors, or potions? (please make sure to type exactly or it will return to main menue)");
				userItemTypeRequest = userInput.nextLine();
				switch (userItemTypeRequest.toUpperCase().charAt(0)) {
				case 'W':
					System.out.println("Here is a list of the weapons we have!");
					gameStore.stateWeaponList();
					System.out.println("Which weapon number would you like to buy? (Please type a Weapon Number)");

					userItemNumSelection = userInput.nextInt();
					// userInput.nextLine();
					System.out.println("Weapon number: " + userItemNumSelection + " is.");
					gameStore.weaponInventoryList.get(userItemNumSelection - 1).stateItemInfo();
					System.out.println("How many of this weapon would you like to buy? (Please Type a number) ");
					userItemQtySelection = userInput.nextInt();
					userInput.nextLine();
					gameStore.addWeaponToCartFromInventoryList(userItemNumSelection, userItemQtySelection);
					System.out.println("Would you like to purchase Weapon: " + userItemNumSelection
							+ " for a total of $" + gameStore.getCartBalance()
							+ " ? (Please type y or n. If you cancel the purchase, you will be sent back to the main menue.");
					userYorN = userInput.next().charAt(0);
					userInput.nextLine();
					if (userYorN == 'y' || userYorN == 'Y') {
						gameStore.purchaseCart();
					} else {
						System.out.println("The following weapon will be removed from the Shopping cart.");
						gameStore.stateAllItemsAllCart();
						gameStore.weaponCartList.remove(0);
						System.out.println(
								"Thank you for shopping with " + gameStore.getName() + " Have a good Day. Good Bye.");
					}
					// end loop
					resetLoop = false;
					break;

				case 'A':
					System.out.println("Here is a list of the armors we have!");
					gameStore.stateArmorList();
					System.out.println("Which armor number would you like to buy? (Please type a armor Number)");

					userItemNumSelection = userInput.nextInt();
					// userInput.nextLine();
					System.out.println("Armor number: " + userItemNumSelection + " is.");
					gameStore.armorInventoryList.get(userItemNumSelection - 1).stateItemInfo();
					System.out.println("How many of this armor would you like to buy? (Please Type a number) ");
					userItemQtySelection = userInput.nextInt();
					userInput.nextLine();
					gameStore.addArmorToCartFromInventoryList(userItemNumSelection, userItemQtySelection);
					System.out.println("Would you like to purchase Armor: " + userItemNumSelection + " for a total of $"
							+ gameStore.getCartBalance()
							+ " ? (Please type y or n. If you cancel the purchase, you will be sent back to the main menue.");
					userYorN = userInput.next().charAt(0);
					userInput.nextLine();
					if (userYorN == 'y' || userYorN == 'Y') {
						gameStore.purchaseCart();
					} else {
						System.out.println("The following armor will be removed from the Shopping cart.");
						gameStore.stateAllItemsAllCart();
						gameStore.armorCartList.remove(0);
						System.out.println(
								"Thank you for shopping with " + gameStore.getName() + " Have a good Day. Good Bye.");
					}
					// end loop
					resetLoop = false;
					break;

				case 'P':
					System.out.println("Here is a list of the potions we have!");
					gameStore.statePotionList();
					System.out.println("Which potion number would you like to buy? (Please type a potion Number)");

					userItemNumSelection = userInput.nextInt();
					// userInput.nextLine();
					System.out.println("Potion Number: " + userItemNumSelection + " is.");
					gameStore.potionInventoryList.get(userItemNumSelection - 1).stateItemInfo();
					System.out.println("How many of this potion would you like to buy? (Please Type a number) ");
					userItemQtySelection = userInput.nextInt();
					userInput.nextLine();
					gameStore.addPotionToCartFromInventoryList(userItemNumSelection, userItemQtySelection);
					System.out.println("Would you like to purchase Armor: " + userItemNumSelection + " for a total of $"
							+ gameStore.getCartBalance()
							+ " ? (Please type y or n. If you cancel the purchase, you will be sent back to the main menue.");
					userYorN = userInput.next().charAt(0);
					userInput.nextLine();
					if (userYorN == 'y' || userYorN == 'Y') {
						gameStore.purchaseCart();
					} else {
						System.out.println("The following potion will be removed from the Shopping cart.");
						gameStore.stateAllItemsAllCart();
						gameStore.potionCartList.remove(0);
						System.out.println(
								"Thank you for shopping with " + gameStore.getName() + " Have a good Day. Good Bye.");
					}
					// end loop
					resetLoop = false;
					break;
				}

			} catch (Exception e) {
				System.out.println("Not a valid entry. Try again");
				userInput.nextLine();

			}
		} while (resetLoop);
		resetLoop = true;
		userInput.close();
	}

}
