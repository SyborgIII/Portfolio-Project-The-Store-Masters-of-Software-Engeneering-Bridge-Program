package stores;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import com.fasterxml.jackson.databind.DatabindException;
import com.fasterxml.jackson.databind.ObjectMapper;

import items.SalableWeapon;
import items.SalableArmor;
import items.SalablePotion;
/**
 * store program that behaves like a store front
 * 
 * @author simon codrington iii
 *
 */
public class DefaultStore implements Runnable {
	/**
	 *class members 
	 */
	public ArrayList<SalableWeapon> weaponInventoryList = new ArrayList<>();
	public ArrayList<SalableArmor> armorInventoryList = new ArrayList<>();
	public ArrayList<SalablePotion> potionInventoryList = new ArrayList<>();
	
	public ArrayList<SalableWeapon> weaponCartList = new ArrayList<>();
	public ArrayList<SalableArmor> armorCartList = new ArrayList<>();
	public ArrayList<SalablePotion> potionCartList = new ArrayList<>();
	
	private String name;
	private boolean storeOpen;
	private boolean storeClosed;
	private double cartBalance;
	
	
	
	
	
	
	/**
	 * default constructor that initializes the state of the store to closed being
	 * true and open to false.
	 */
	public DefaultStore() {
		this.name = "Game Store";
		this.storeOpen = true;
		this.storeClosed = false;
		this.cartBalance = 0;
	}

	/**
	 * non default constructor
	 * 
	 * @param name
	 * @param storeOpen
	 * @param storeClosed
	 * @param cartBalance
	 */
	public DefaultStore(String name, boolean storeOpen, boolean storeClosed, double cartBalance) {
		this.name = name;
		this.storeOpen = storeOpen;
		this.storeClosed = storeClosed;
		this.cartBalance = cartBalance;
		
	}

	/**
	 * method to open the store and will check to make sure the inventory list has
	 * items in it if there is no items the store will not open and set the state
	 * accordingly.
	 */
	public void openStore() {
		if (weaponInventoryList.size() > 0 || armorInventoryList.size() > 0 || potionInventoryList.size() > 0) {
			this.storeOpen = true;
			this.storeClosed = false;
			//System.out.println("The store named " + this.name + " was just opened");
		} else {
			this.storeOpen = false;
			this.storeClosed = true;
			System.out.println("The store named " + this.name + " can not be opened due to there being no items "
					+ "in the inventory list.");
		
		}
	}

	/**
	 * method to close the store and set values accordingly
	 */
	public void closeStore() {
		this.storeClosed = true;
		this.storeOpen = false;
		//System.out.println("The store named " + this.name + " was just closed");
	}

	/**
	 * adds item to weapon inventory list 
	 * 
	 * @param name
	 * @param type
	 * @param price
	 * @param qty
	 */
	public void addSalableWeaponInventoryList(String name, String type, double price, int stock) {
		SalableWeapon newSalableWeapon = new SalableWeapon();
		newSalableWeapon.setName(name);
		newSalableWeapon.setPrice(price);
		newSalableWeapon.setType(type);
		newSalableWeapon.setStock(stock);
		weaponInventoryList.add(newSalableWeapon);
		//System.out.println("The following item was added to the inventory list:");
		//System.out.println("Item number " + inventoryList.size());
		//inventoryList.get(inventoryList.size() - 1).stateItemInfo();
	}
	public void addWeaponToWeaponInventoryListJson(File weaponJsonFile, SalableWeapon weaponToAdd) throws DatabindException, IOException{
		ObjectMapper objectMapper = new ObjectMapper();
		weaponToAdd = objectMapper.readValue(weaponJsonFile, SalableWeapon.class); 
		weaponInventoryList.add(weaponToAdd);
	}
	
	public void addArmorToArmorInventoryListJson(File armorJsonFile, SalableArmor armorToAdd) throws DatabindException, IOException{
		ObjectMapper objectMapper = new ObjectMapper();
		armorToAdd = objectMapper.readValue(armorJsonFile, SalableArmor.class); 
		armorInventoryList.add(armorToAdd);
	}
	public void addPotionToPotionInventoryListJson(File potionJsonFile, SalablePotion potionToAdd) throws DatabindException, IOException{
		ObjectMapper objectMapper = new ObjectMapper();
		potionToAdd = objectMapper.readValue(potionJsonFile, SalablePotion.class); 
		potionInventoryList.add(potionToAdd);
	}
	/**
	 * adds item to armor inventory list 
	 * 
	 * @param name
	 * @param type
	 * @param price
	 * @param qty
	 */
	public void addSalableArmorInventoryList(String name, String type, double price, int stock) {
		SalableArmor newSalableArmor = new SalableArmor();
		newSalableArmor.setName(name);
		newSalableArmor.setPrice(price);
		newSalableArmor.setType(type);
		newSalableArmor.setStock(stock);
		armorInventoryList.add(newSalableArmor);
		//System.out.println("The following item was added to the inventory list:");
		//System.out.println("Item number " + inventoryList.size());
		//inventoryList.get(inventoryList.size() - 1).stateItemInfo();
	}
	/**
	 * adds item to potion inventory list 
	 * 
	 * @param name
	 * @param type
	 * @param price
	 * @param qty
	 */
	public void addSalablePotionInventoryList(String name, String type, double price, int stock) {
		SalablePotion newSalablePotion = new SalablePotion();
		newSalablePotion.setName(name);
		newSalablePotion.setPrice(price);
		newSalablePotion.setType(type);
		newSalablePotion.setStock(stock);
		potionInventoryList.add(newSalablePotion);
		//System.out.println("The following item was added to the inventory list:");
		//System.out.println("Item number " + inventoryList.size());
		//inventoryList.get(inventoryList.size() - 1).stateItemInfo();
	}

	
	/**
	 * method used to add an item to the shopping cart from an item number and then
	 * state what was added based on parameters method will print statement to show
	 * how much quantity left in stock. method should catch and print most errors is
	 * not enough in stock or not a valid item number
	 * 
	 * @param itemNum
	 * @param qtyBaught
	 */
	public void addWeaponToCartFromInventoryList(int itemNum, int qtyBaught) {
	//	if (inventoryList.get(itemNum - 1).getQty() >= qtyBaught) {
			SalableWeapon newCartWeapon = new SalableWeapon();
			newCartWeapon.setName(weaponInventoryList.get(itemNum - 1).getName());
			newCartWeapon.setPrice(weaponInventoryList.get(itemNum - 1).getPrice());
			newCartWeapon.setType(weaponInventoryList.get(itemNum - 1).getType());
			newCartWeapon.setStock(qtyBaught);
			weaponCartList.add(newCartWeapon);
			weaponInventoryList.get(itemNum - 1).deductStock(qtyBaught);
			System.out.println("The folloing weapon was added to the shopping cart ");
			System.out.println("Item number " + itemNum );
			weaponCartList.get(weaponCartList.size() - 1).stateItemInfo();
			calculateCartBalance();
			System.out.println("The Shopping Cart balance is $" + this.cartBalance);
			//System.out.println("There are " + inventoryList.get(itemNum - 1).getQty() + " units left in stock");
		//} else {
		//	System.out.println("Not enough in stock.");
	//	}
	}
	public void addArmorToCartFromInventoryList(int itemNum, int qtyBaught) {
		//	if (inventoryList.get(itemNum - 1).getQty() >= qtyBaught) {
				SalableArmor newCartArmor = new SalableArmor();
				newCartArmor.setName(armorInventoryList.get(itemNum - 1).getName());
				newCartArmor.setPrice(armorInventoryList.get(itemNum - 1).getPrice());
				newCartArmor.setType(armorInventoryList.get(itemNum - 1).getType());
				newCartArmor.setStock(qtyBaught);
				armorCartList.add(newCartArmor);
				armorInventoryList.get(itemNum - 1).deductStock(qtyBaught);
				System.out.println("The folloing armor was added to the shopping cart ");
				System.out.println("Item number " + itemNum );
				armorInventoryList.get(armorInventoryList.size() - 1).stateItemInfo();
				calculateCartBalance();
				System.out.println("The Shopping Cart balance is $" + this.cartBalance);
				//System.out.println("There are " + inventoryList.get(itemNum - 1).getQty() + " units left in stock");
			//} else {
			//	System.out.println("Not enough in stock.");
		//	}
		}
	public void addPotionToCartFromInventoryList(int itemNum, int qtyBaught) {
		//	if (inventoryList.get(itemNum - 1).getQty() >= qtyBaught) {
				SalablePotion newCartPotion = new SalablePotion();
				newCartPotion.setName(potionInventoryList.get(itemNum - 1).getName());
				newCartPotion.setPrice(potionInventoryList.get(itemNum - 1).getPrice());
				newCartPotion.setType(potionInventoryList.get(itemNum - 1).getType());
				newCartPotion.setStock(qtyBaught);
				potionCartList.add(newCartPotion);
				potionInventoryList.get(itemNum - 1).deductStock(qtyBaught);
				System.out.println("The folloing potion was added to the shopping cart ");
				System.out.println("Item number " + itemNum );
				potionInventoryList.get(potionInventoryList.size() - 1).stateItemInfo();
				calculateCartBalance();
				System.out.println("The Shopping Cart balance is $" + this.cartBalance);
				//System.out.println("There are " + inventoryList.get(itemNum - 1).getQty() + " units left in stock");
			//} else {
			//	System.out.println("Not enough in stock.");
		//	}
		}

	/**
	 * remove a specific item from the shopping cart based on parameter will print
	 * the item that was removed
	 * 
	 * @param itemNum
	 */
	public void removeItemAnyList(ArrayList<Object> itemList, int itemNum) {
		itemList.remove(itemNum - 1);
		//System.out.println("The following item was removed:");
		//System.out.println("Item number " + itemNum );
		//itemList.get(itemNum - 1).stateItemInfo();
	}

	/**
	 * method to purchase contents of the shopping cart. method will check to make
	 * sure that the store is open and the cart has items in the list method will
	 * print that the customer made a purchase
	 */
	public void calculateCartBalance() {
		for(int i = 0; i < weaponCartList.size(); i++) {
			this.cartBalance = weaponCartList.get(i).getPrice() * weaponCartList.get(i).getStock() + this.cartBalance;
		}
		for(int i = 0; i < armorCartList.size(); i++) {
			this.cartBalance = armorCartList.get(i).getPrice() * armorCartList.get(i).getStock() + this.cartBalance;
		}
		for(int i = 0; i < potionCartList.size(); i++) {
			this.cartBalance = potionCartList.get(i).getPrice() * potionCartList.get(i).getStock() + this.cartBalance;
		}

	}
	public void purchaseCart() {
		if (this.storeOpen ) {
			System.out.println("The following items were just purchased for a total of $" + this.cartBalance + " dolars." );
			stateAllItemsAllCart();
			System.out.println("Thank you for your purchase.");
		} else if (this.storeClosed) {
			System.out.println("Sorry but the store is closed");
		} 
	}
	/**
	 * method that prints out all the contents of the default item array list that was passed as a parameter
	 * @param itemList
	 */
	public void stateWeaponList() {
		for(int i = 0; i < this.weaponInventoryList.size(); i++) {
			System.out.println("Weapon: " + (i+1));
			System.out.println("Weapon Name: " + this.weaponInventoryList.get(i).getName() );
			System.out.println("Weapon Type: " + this.weaponInventoryList.get(i).getType() );
			System.out.println("Weapon Price: " + this.weaponInventoryList.get(i).getPrice() );
			//System.out.println("Item Quantity: " + itemList.get(i).getQty() );
		}
	}
	public void stateArmorList() {
		for(int i = 0; i < this.armorInventoryList.size(); i++) {
			System.out.println("Armor: " + (i+1));
			System.out.println("Armor Name: " + this.armorInventoryList.get(i).getName() );
			System.out.println("Armor Type: " + this.armorInventoryList.get(i).getType() );
			System.out.println("Armor Price: " + this.armorInventoryList.get(i).getPrice() );
			//System.out.println("Item Quantity: " + itemList.get(i).getQty() );
		}
	}
	public void statePotionList() {
		for(int i = 0; i < this.potionInventoryList.size(); i++) {
			System.out.println("Potion: " + (i+1));
			System.out.println("Potion Name: " + this.potionInventoryList.get(i).getName() );
			System.out.println("Potion Type: " + this.potionInventoryList.get(i).getType() );
			System.out.println("Potion Price: " + this.potionInventoryList.get(i).getPrice() );
			//System.out.println("Item Quantity: " + itemList.get(i).getQty() );
		}
	}
	
	/**
	 * method that prints out all the contents of the default item array list that was passed as a parameter
	 * @param itemList
	 */
	public void stateAllItemsAllCart() {
		for(int i = 0; i < this.weaponCartList.size(); i++) {
			System.out.println("Weapon: " + (i+1));
			System.out.println("Weapon Name: " + this.weaponCartList.get(i).getName() );
			System.out.println("Weapon Type: " + this.weaponCartList.get(i).getType() );
			System.out.println("Weapon Price: " + this.weaponCartList.get(i).getPrice() );
			System.out.println("Weapon Quantity: " + this.weaponCartList.get(i).getStock() );
		}
		for(int i = 0; i < this.armorCartList.size(); i++) {
			System.out.println("Armor: " + (i+1));
			System.out.println("Armor Name: " + this.armorCartList.get(i).getName() );
			System.out.println("Armor Type: " + this.armorCartList.get(i).getType() );
			System.out.println("Armor Price: " + this.armorCartList.get(i).getPrice() );
			System.out.println("Armor Quantity: " + this.armorCartList.get(i).getStock() );
		}
		for(int i = 0; i < this.potionCartList.size(); i++) {
			System.out.println("Potion: " + (i+1));
			System.out.println("Potion Name: " + this.potionCartList.get(i).getName() );
			System.out.println("Potion Type: " + this.potionCartList.get(i).getType() );
			System.out.println("Potion Price: " + this.potionCartList.get(i).getPrice() );
			System.out.println("Potion Quantity: " + this.potionCartList.get(i).getStock() );
		}
	}
	
	/**
	 * setters and getters 
	 */
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}


	public boolean isStoreOpen() {
		return storeOpen;
	}

	public void setStoreOpen(boolean storeOpen) {
		this.storeOpen = storeOpen;
	}

	public boolean isStoreClosed() {
		return storeClosed;
	}

	public void setStoreClosed(boolean storeClosed) {
		this.storeClosed = storeClosed;
	}

	public double getCartBalance() {
		return cartBalance;
	}

	public void setCartBalance(double cartBalance) {
		this.cartBalance = cartBalance;
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		
	}
	
	
	
	
}
