package items;

public interface SalableItemInterface {
	
	public void addStock(int raise);
	public void deductStock(int deduct);
	public void stateItemInfo();
	

}
