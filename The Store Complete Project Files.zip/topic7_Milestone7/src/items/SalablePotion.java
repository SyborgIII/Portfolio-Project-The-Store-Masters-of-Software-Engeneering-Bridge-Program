package items;

public class SalablePotion implements SalableItemInterface{
	/**
	 * class variables and objects
	 */
	private String name;
	private String type;
	private double price;
	private int stock;

	/**
	 * @override default constructor to initialize variables to default values
	 */
	public SalablePotion() {
		this.name = "Default Potion Name";
		this.type = "Default Potion Type";
		this.price = 0;
		this.stock = 0;
	}

	/**
	 * non default constructor
	 * 
	 * @param name
	 * @param type
	 * @param price
	 * @param qty
	 */
	public SalablePotion(String name, String type, double price, int unitStock) {
		this.name = name;
		this.type = type;
		this.price = price;
		this.stock = unitStock;
	}
	@Override
	public void addStock(int raise) {
		this.stock = this.stock + raise;
		
	}

	@Override
	public void deductStock(int deduct) {
		this.stock = this.stock - deduct;
		
	}
	@Override
	public void stateItemInfo() {
		System.out.println("Potion Name: " + this.name);
		System.out.println("Potion Type: " + this.type);
		System.out.println("Potion Price: " + this.price);
		System.out.println("Potions in Stock: " + this.stock);
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public int getStock() {
		return stock;
	}

	public void setStock(int stock) {
		this.stock = stock;
	}
	
}
